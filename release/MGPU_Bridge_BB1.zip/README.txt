MGPU Bridge BB1 - 帧生成闪烁横条修复版
基于 davidm71 分支 commit c40734d (DG3)

修复内容
  - 开启帧生成后，游戏在前台时画面上的闪烁黑条和面板闪烁
  - 面板小光标有时动不了，以及关闭面板后留在屏幕上

安装（需要已装好可用的 MGPU Bridge DG3）
  1. 完全退出游戏。
  2. 备份游戏目录（dxgi.dll 旁边）里的 nvngx.dll_mgpu_bridge.addon64。
  3. 用本包里的同名文件覆盖它。
  4. 不要覆盖你的 mgpu.ini。不加任何配置就默认使用 6 个缓冲。
  5. 进游戏后查看 ReShade.log，应该能看到 source BB1 和 buffers=6。

回退：把备份改回原名即可。

测试范围：只在 2 x RTX 5080、驱动 621.01、《剑星》、4K 120Hz 上测试过。
其他显卡、游戏和设置都没有验证。缩放器（Scaler）路径未实际运行。

----------------------------------------------------------------------

MGPU Bridge BB1 - frame generation flicker fix
Based on davidm71's fork, commit c40734d (DG3)

Fixes
  - Flickering dark bands and panel flicker with frame generation on, game focused
  - Panel pointer that sometimes does not move and stays on screen after closing

Install (needs a working MGPU Bridge DG3)
  1. Exit the game completely.
  2. Back up nvngx.dll_mgpu_bridge.addon64 in the game folder, next to dxgi.dll.
  3. Replace it with the file of the same name from this package.
  4. Do not overwrite your mgpu.ini. With no new keys, 6 buffers is the default.
  5. In-game, ReShade.log should show source BB1 and buffers=6.

Roll back by restoring your backup.

Tested only on 2 x RTX 5080, driver 621.01, Stellar Blade, 4K 120 Hz.
Other GPUs, games and settings are unverified. The Scaler path was not run.
